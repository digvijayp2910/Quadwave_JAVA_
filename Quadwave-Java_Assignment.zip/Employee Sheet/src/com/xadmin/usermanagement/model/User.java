package com.xadmin.usermanagement.model;

/**
 * User.java
 * This is a model class represents a User entity
 * @author Ramesh Fadatare
 *
 */
public class User {
	protected int id;
	protected String name;
	protected String email;
	protected String country;
	
	public User() {
	}
	
	public User(int Eid, String EName, String DOJ, int YOE, String Designation) {
		super();
		this.EName = EName;
		this.Eid = Eid;
		this.DOJ = DOJ;
		this.YOE=YOE;
		this.Designation= Designation;
	}

	public User(int Eid, String EName, String DOJ, int YOE, String Designation) {
		super();
		this.EName = EName;
		this.Eid = Eid;
		this.DOJ = DOJ;
		this.YOE=YOE;
		this.Designation= Designation;
	}

	public int getid() {
		return Eid;
	}
	public void setid(int Eid) {
		this.Eid = Eid;
	}
	public String getName() {
		return EName;
	}
	public void setName(String name) {
		this.EName = name;
	}
	public String getDOJ() {
		return DOJ;
	}
	public void setDOJ(String DOJ) {
		this.DOJ = DOJ;
	}
	public String getYOE() {
		return YOE;
	}
	public void setYOE(int YOE) {
		this.YOE = YOE;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String Designation) {
		this.Designation = Designation;
	}
}